package com.example.mynilai_irvan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class BobotNilaiActivity extends AppCompatActivity {

    EditText nBobotHadir, nBobotTugas, nBobotUTS, nBobotUAS;
    Double hadir, tugas, uts, uas, nakhir;
    Double bobotHadir, bobotTugas, bobotUTS, bobotUAS;

    String grade;
    TextView tAkhir, nGrade;
    Button Btnext2;

    String nim, nama, matkul;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bobot_nilai);

        String kehadiran = getIntent().getExtras().getString("kehadiran");
        matkul = getIntent().getExtras().getString("matkul");
        tugas = Double.valueOf(getIntent().getExtras().getString("tugas"));
        uts = Double.valueOf(getIntent().getExtras().getString("uts"));
        uas = Double.valueOf(getIntent().getExtras().getString("uas"));
        nim = getIntent().getExtras().getString("nim");
        nama = getIntent().getExtras().getString("nama");

        nBobotHadir = findViewById(R.id.hadiran);
        nBobotTugas = findViewById(R.id.nTugas);
        nBobotUTS = findViewById(R.id.nlUTS);
        nBobotUAS = findViewById(R.id.nlUAS);

        tAkhir = findViewById(R.id.takhir);
        nGrade = findViewById(R.id.tgrade);
        Btnext2 = findViewById(R.id.next2);

        Btnext2.setOnClickListener(view -> {

            hadir = Double.parseDouble(kehadiran);
            bobotHadir = Double.parseDouble(nBobotHadir.getText().toString());
            bobotTugas = Double.parseDouble(nBobotTugas.getText().toString());
            bobotUTS = Double.parseDouble(nBobotUTS.getText().toString());
            bobotUAS = Double.parseDouble(nBobotUAS.getText().toString());

            nakhir = (hadir * (bobotHadir/100)) + (tugas * (bobotTugas/100)) + (uts * (bobotUTS/100)) + (uas * (bobotUAS/100));

            if (nakhir >= 80) {
                grade = "Nilai A";
            } else if (nakhir >= 65) {
                grade = "Nilai B";
            } else if (nakhir >= 55) {
                grade = "Nilai C";
            } else if (nakhir >= 40) {
                grade = "Nilai D";
            } else {
                grade = "Nilai E";
            }

            tAkhir.setText("" + nakhir);
            nGrade.setText("" + grade);

            Intent i = new Intent(BobotNilaiActivity.this, HasilActivity.class);
            i.putExtra("akhir", tAkhir.getText().toString());
            i.putExtra("grade", nGrade.getText().toString());
            i.putExtra("nim", nim);
            i.putExtra("nama", nama);
            i.putExtra("matkul", matkul);
            startActivity(i);
        });
    }
}